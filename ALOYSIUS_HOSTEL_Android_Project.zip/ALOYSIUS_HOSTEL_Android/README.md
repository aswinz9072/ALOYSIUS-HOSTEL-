# ALOYSIUS HOSTEL Android app

This project packages the finalized v13 standalone ALOYSIUS HOSTEL interface inside a real Android application using an embedded local WebView. It has no university backend connection and no internet permission.

Open the project in Android Studio and run/build the `app` module.

Application ID: `com.aloysiushostel.app`
Minimum Android: 6.0 (API 23)
Target SDK: 35
