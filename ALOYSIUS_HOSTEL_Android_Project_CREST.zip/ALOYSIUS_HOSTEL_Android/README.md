# ALOYSIUS HOSTEL Android App

Standalone local Android build of the ALOYSIUS HOSTEL UI prototype.

- Embedded local WebView UI
- Leave and Gate Pass workflows are local/demo workflows
- No university backend or INTERNET permission
- Launcher icon uses the exact St Aloysius crest image supplied for this build
