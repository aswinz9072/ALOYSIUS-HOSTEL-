# ALOYSIUS HOSTEL Android project

Standalone local Android WebView app containing the V13 hostel UI.

Launcher icon: custom ALOYSIUS HOSTEL icon, intentionally distinct from the university crest.

Build debug APK with Gradle 8.7 / Android SDK 35.
